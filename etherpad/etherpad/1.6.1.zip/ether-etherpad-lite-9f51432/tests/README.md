# About this folder: Tests

## Frontend

To run the tests, point your browser to `<yourdomainhere>/tests/frontend`

## Backend

To run the tests, run ``bin/backendTests.sh``
